#include "SleepableBed.h"
#define FLAGS (ACTOR_FLAG_0)


void SleepableBed_Init(SleepableBed* this, PlayState* play);
void SleepableBed_Destroy(SleepableBed* this, PlayState* play);
void SleepableBed_Update(SleepableBed* this, PlayState* play);
void SleepableBed_Draw(SleepableBed* this, PlayState* play);
void SleepableBed_Transport(SleepableBed* this, PlayState* play);
void SleepableBed_Talk(SleepableBed* this, PlayState* play);


const ActorInit sSleepableBed_InitVars = {
    .id = 0x0207,
    .category     = ACTORCAT_PROP,
    .flags        = 0x00000031,
    .objectId = OBJECT_GAMEPLAY_KEEP,
    .instanceSize = sizeof(SleepableBed),
    .init         = (ActorFunc)SleepableBed_Init,
    .destroy      = (ActorFunc)SleepableBed_Destroy,
    .update       = (ActorFunc)SleepableBed_Update,
    .draw         = (ActorFunc)SleepableBed_Draw
};

OvlMessage gIntroduceText = {
    .type = MSGBOX_TYPE_BLACK,
    .pos = MSGBOX_POS_BOTTOM,
    .txt =
    "A good rest would \x05\x02heal your wounds\x05\x00..."

};

OvlMessage gChoiceText = {
    .type = MSGBOX_TYPE_BLACK,
    .txt =
        "Go to bed now?\n\n"
        MSG_TWO_CHOICE MSG_COLOR_REG_0 MSG_INSTANT_ON
        "Yes\n"
        "Not yet"
        MSG_COLOR_DEFAULT MSG_INSTANT_OFF
    

};

OvlMessage gAnswerText[] = {
    {   
        .type = MSGBOX_TYPE_NONE_NO_SHADOW,
        .pos = MSGBOX_POS_BOTTOM,
        .txt =
            MSG_TEXT_SPEED("\x00")
            "\x05\x01Sleep "
            MSG_TEXT_SPEED("\x01")
            "\x05\x01Well"
            MSG_TEXT_SPEED("\x02")
            "\x05\x01..."
            MSG_TEXT_SPEED("\x03")
            "\x05\x01..."
            MSG_TEXT_SPEED("\x04")
            "\x05\x01..."
            MSG_FADE("\x180")
    },{
        .type = MSGBOX_TYPE_NONE_NO_SHADOW,
        .pos = MSGBOX_POS_BOTTOM,
        .txt =
            MSG_INSTANT_ON
            "    "
            MSG_FADE("\x01")
            MSG_INSTANT_OFF

    },
};

void SleepableBed_Init(SleepableBed* this, PlayState* play) {
    OvlMessage_Init(&this->actor, false);
    this->actor.targetMode = 0;
    this->cutsceneTimer = 5;
}

void SleepableBed_Destroy(SleepableBed* this, PlayState* play) {
}

void SleepableBed_Transport(SleepableBed* this, PlayState* play){

    if (this->cutsceneTimer > 0) {
        this->cutsceneTimer--;
    }
    else {
        gSaveContext.health = gSaveContext.healthCapacity;
        Magic_Fill(play);
        func_8006D074(play);
        play->nextEntranceIndex = 0x54;//temple of time
        if(gSaveContext.deaths % 5 == 0 && gSaveContext.deaths >= 5){
            play->transitionType = TRANS_TYPE_CIRCLE(TCA_STARBURST, TCC_WHITE, TCS_SLOW);
        }else{
            play->transitionType = TRANS_TYPE_CIRCLE(TCA_STARBURST, TCC_BLACK, TCS_SLOW);
        }
        play->transitionTrigger = TRANS_TRIGGER_START;
    }


}

void SleepableBed_Talk(SleepableBed* this, PlayState* play){
    s8 decision;

    if(OvlMessage_IsCurrentMessage(&gIntroduceText)){
        OvlMessage_SetBranch(&gChoiceText);
    }

    if(OvlMessage_IsCurrentMessage(&gChoiceText)){
        if((decision = OvlMessage_GetChoice(&this->actor))){
            OvlMessage_Continue(&this->actor,&gAnswerText[decision - 1]);
            if(decision == 1){
                if(gSaveContext.deaths % 5 == 0 && gSaveContext.deaths >= 5){
                    this->cutsceneTimer = 120;
                    func_800F5ACC(NA_BGM_OCA_ZELDA);  
                }else{
                    this->cutsceneTimer = 20;
                }
            }
        }

    }

    if(OvlMessage_IsCurrentMessage(&gAnswerText[1])){
         if(OvlMessage_IsClosed(&this->actor)){
         this->actor.update = (ActorFunc)SleepableBed_Update;
         }
    }else if(OvlMessage_IsCurrentMessage(&gAnswerText[0])){
        SleepableBed_Transport(this,play);
    }

}

void SleepableBed_Update(SleepableBed* this, PlayState* play) {
     if(ABS(this->actor.yDistToPlayer) < 20.0f){
        if(OvlMessage_Prompt(&this->actor,&gIntroduceText,120,0) > 0){
            OvlMessage_RegisterColor(0,0,255,0);
            this->actor.update = (ActorFunc)SleepableBed_Talk;
        }
     }
    Actor_SetFocus(&this->actor, 28.0f);

}

s32 SleepableBed_OverrideLimbDraw(PlayState* play, s32 limbIndex, Gfx** dl, Vec3f* pos, Vec3s* rot, void* thisx) {
    SleepableBed* this = (void*)thisx;
    
    return 0;
}

void SleepableBed_PostLimbDraw(PlayState* play, s32 limbIndex, Gfx** dl, Vec3s* rot, void* thisx) {
    SleepableBed* this = (void*)thisx;
}

void SleepableBed_Draw(SleepableBed* this, PlayState* play) {
}
